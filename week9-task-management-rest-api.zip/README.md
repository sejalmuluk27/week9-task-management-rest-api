# Week 9 Task Management REST API

This starter project includes a Flask REST API with JWT authentication outline.

## Run
```bash
pip install -r requirements.txt
python run.py
```
